package vn.hcmute.nhom02.foody.common;

import vn.hcmute.nhom02.foody.signup.User;

/**
 * Create by: IntelliJ IDEA
 * User     : trongnt
 * Date     : Tue, 4/26/2022
 * Time     : 8:43 PM
 * Filename : Common
 */
public class Common {
    public static boolean isLogin = false;
    public static User currentUser = null;
}
