package vn.hcmute.nhom02.foody.Activity;

import android.os.Bundle;
import android.util.Base64;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class MainActivity extends AppCompatActivity implements IMainAdminActivity {

    @Override
    public void loadFragment(Fragment fragment) {

    }

    @Override
    public void sendSms(String toPhoneNumber, String message) {

    }
}
